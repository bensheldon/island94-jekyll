TO INSTALL:

Drop this folder into your active theme's directory (e.g. /sites/default/all/garland), it should take effect without any other modifications---though you may have to reset the theme cache (goto admin/build/themes and click save without making any other changes).

ABOUT:

This is primarily based off of the Filefield module's theme code that displays a custom icon based upon mimetype.  That code was then adapted to override the core Upload module's display

CONTACT:

Ben Sheldon
bensheldon@gmail.com

August 8, 2008